---
layout : post
title : "待办事项"
category : 其它
duoshuo: true
date : 0000-11-11
tags : [其它]
---



安卓多渠道打包工具

[https://github.com/GavinCT/AndroidMultiChannelBuildTool](https://github.com/GavinCT/AndroidMultiChannelBuildTool)


----

美团Android自动化之旅—生成渠道包

[http://tech.meituan.com/mt-apk-packaging.html](http://tech.meituan.com/mt-apk-packaging.html)

----

Android批量打包提速 - 1分钟900个市场不是梦

http://www.cnblogs.com/ct2011/p/4152323.html


-----
