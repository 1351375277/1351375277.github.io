---
layout : post
title : "娱乐一下"
category : HTML
duoshuo: true
date : 2014-10-22
tags : [HTML5 ,HTML  ]
---

<iframe src="/res/game/plane/plane.html" width="100%" height="1000px" align="middle"  scrolling="no" frameborder="1px"></iframe>

<!--more-->

<a href="/res/game/plane/plane.html">娱乐链接</a>